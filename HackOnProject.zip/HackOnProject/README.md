


# 🛡️ Motion Detection & Unusual Behavior Monitoring System  

## 📌 Overview  
This project is designed for **real-time motion detection, facial recognition, and automated alerts** using **Python, OpenCV, and a MERN stack**. It is useful for **security surveillance, smart monitoring, and anomaly detection** in **public places, offices, or homes**.  

## 🚀 Features  
✅ **Real-time Motion Detection** using OpenCV  
✅ **Facial Recognition** for identifying individuals  
✅ **Automated Alerts** via **Mailgun (Email) & Twilio (SMS)**  
✅ **MERN Stack Dashboard** for event monitoring & logs  
✅ **MongoDB Integration** for storing security logs  

## 🏗️ System Architecture  
This project consists of two main components:  
- **Python (Backend AI Processing)** handles motion detection using **OpenCV**, recognizes faces, and triggers alerts when unusual activity is detected.  
- **MERN Stack (Frontend & Backend)** consists of a **Node.js + Express.js** backend that manages API requests, **MongoDB** for storing security logs, and a **React frontend** for live event monitoring.  
- **Alert System** uses **Mailgun** for email alerts and **Twilio** for SMS notifications.  

---

## 🛠 Installation  

### **1️⃣ Install Python & Required Libraries**  
1. Install **Python 3.12** from [here](https://www.python.org/downloads/)  
2. Install the required Python libraries by running:  
   ```sh
   pip install -r requirements.txt


This **README.md** file includes:  
- **Installation steps for Python & MERN**  
- **How to run the scripts**  
- **MongoDB setup**  
- **Mailgun & Twilio configuration**  
- **Use cases and future improvements**  

Let me know if you need any modifications! 🚀
